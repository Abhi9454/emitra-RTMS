var ws = new WebSocket("ws://localhost:9999");
		console.log("socket object created => "+ws+"\n\n");
		ws.onopen = (event)=>{
			// ws.send(JSON.stringify(_obj));
			// console.log("code send successfully with state "+ws.readyState);
			console.log(`Got a connection from ${event}`);
		
		};
		ws.onmessage = (event)=>{
			if(ws.readyState===1)
				{	
					var $data = JSON.parse(event.data);
					console.log(`recieve data => ${$data}`);
				}
		};
		ws.onclose = ()=>{
			console.log('connection finish');
		};

$(document).ready(function(){
	// var pinColor = "FE7569";
	var getPinImage = (pinColor)=>{
		return new google.maps.MarkerImage("http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|" + pinColor,
		    new google.maps.Size(21, 34),
		    new google.maps.Point(0,0),
		    new google.maps.Point(10, 34));
	};
	var pinShadow = new google.maps.MarkerImage("http://chart.apis.google.com/chart?chst=d_map_pin_shadow",
	    new google.maps.Size(40, 37),
	    new google.maps.Point(0, 0),
	    new google.maps.Point(12, 35));

	var setMarker = (lat, lng, markerColor)=>{
		let marker = new google.maps.Marker({
			position: new google.maps.LatLng(lat, lng),
			icon: getPinImage(markerColor),
			pinShadow: pinShadow,
			title: "Click me to get details"
		});
		marker.setMap(map);
		marker.addListener('click',(e)=>{
			// console.log(marker.icon.url);
			let colorCode = marker.icon.url.slice(marker.icon.url.indexOf('|')+1);
			// console.log(`${marker.internalPosition.lat()}: ${marker.position.lat()}`);
			// console.log(`${marker.internalPosition.lat()}: ${marker.position.lat()}`);
			let lat = marker.position.lat();
			let lng = marker.position.lng();
			// console.log(marker.title);
			let title = marker.title;
			displayDetailsOfMarkedPlaced(colorCode, {latitude: lat, longitude: lng}, title);
		});
	}
	window.setTimeout(function(){
		setMarker(26.9124336, 75.7872709, '4CAF50');
		setMarker(26.4498954, 74.6399163, '448AFF');
		setMarker(29.5815012, 74.3294199, 'D50000');
		setMarker(27.0285581, 74.7146215, '448AFF');
		setMarker(28.7042996, 72.5929804, 'D50000');
		setMarker(24.0316509, 74.7787387, '4CAF50');
		setMarker(28.2920484, 74.9617924, '448AFF');
		setMarker(29.9038399, 73.8771901, '4CAF50');
		setMarker(26.0522835, 74.771793, '448AFF');
		setMarker(26.0377772, 76.3521514, 'D50000');
		setMarker(26.2389469, 73.0243094, '4CAF50');
		setMarker(24.585445, 73.712479, '448AFF');
		setMarker(24.8851548, 72.8574558, '4CAF50');
		setMarker(25.1256823, 72.1416132, '448AFF');
		setMarker(25.7531537, 71.4180622, 'D50000');
		setMarker(28.1288747, 75.3995089, 'D50000');
		setMarker(25.0714851, 73.8830701, '448AFF');
		setMarker(26.1620402, 75.7894716, '4CAF50');
		setMarker(25.3033997, 73.9212858, 'D50000');
		setMarker(26.7025181, 77.893391, 'D50000');
		// alert('marker set sucessfull');
	},1000);


	$('.md-template-modal span.close').click(function(){
		$(this).parent().removeClass('active').parent().removeClass('active');
	});


	

	var chart = new CanvasJS.Chart("chartContainer", {
		theme: "light1", // "light1", "light2", "dark1", "dark2"
		exportEnabled: true,
		animationEnabled: true,
		title: {
			text: "Summary of node over 1 week"
		},
		data: [{
			type: "pie",
			startAngle: 25,
			toolTipContent: "<b>{label}</b>: {y}%",
			showInLegend: "true",
			legendText: "{label}",
			indexLabelFontSize: 12,
			indexLabel: "{label} - {y}%",
			dataPoints: [
				{ y: 45.67, label: "Active Node" },
				{ y: 32.1, label: "Inactive Node" },
				{ y: 20, label: "Uploading mode" }
			]
		}]
	});
	chart.render();

	var status2 = [11,56.782,45,55.1,9.123,13.7,78,44,10,3.789];

	function drawChart(){
		var index1 = getRandomIndex();
		var index2 = getRandomIndex();
		var index3 = getRandomIndex();
		// console.log(index1);
		// status = JSON.parse(status);
		// console.log(status[index]);
		chart.options.data[0].dataPoints= [
														{ y: status2[index1], label: "Active Node" },
														{ y: status2[index2], label: "Inactive Node" },
														{ y: status2[index3], label: "Uploading mode" }
											]
											chart.render();
		}

	function displayDetailsOfMarkedPlaced(cc, position, title){
		// alert(`colorCode: ${cc}\nposition: {lat: ${position.latitude}, ${position.longitude}}\ntitle: ${title}`);


		let overlay = document.querySelector('.md-template-overlay');
		overlay.classList.add('active');
		let template = document.querySelector('.md-template-modal');
		template.classList.add('active');
		let node = $('.md-template-overlay .md-template-modal .node-name');
		node.html(title);
		$('.md-template-overlay .md-template-modal .left .latitude').html(position.latitude.toFixed(6));
		$('.md-template-overlay .md-template-modal .left .longitude').html(position.longitude.toFixed(6));
		// console.log(cc);
		$('.md-template-overlay .md-template-modal .right .status-color-box').css("background-color",'#'+cc);
		drawChart();
	}
	
});



var status = [{y:[11,22,34]},{y:[56.5, 78.1, 10.4]}, {y:[45,78.90, 23.67]}, {y:[11.56,12.89,34]},{y:[56.5, 48.1, 15.4]}, {y:[75,78.90, 23.37]}, {y:[41,62,34]},{y:[26.5, 58.1, 30.4]}, {y:[35,18.90, 13.67]}, {y: [33,67.001,51.1]}];

function getRandomIndex(){
	return Math.floor(Math.random() * 10)
}
