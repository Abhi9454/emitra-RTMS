var ws = new WebSocket("ws://localhost:9998");
		console.log("socket object created => "+ws+"\n\n");
		ws.onopen = (event)=>{
			// ws.send(JSON.stringify(_obj));
			// console.log("code send successfully with state "+ws.readyState);
			console.log(`Got a connection from ${event}`);
		
		};
		ws.onmessage = (event)=>{
			if(ws.readyState===1)
				{	
					var $data = JSON.parse(event.data);
					console.log(`recieve data => ${$data}`);
				}
		};
		ws.onclose = ()=>{
			console.log('connection finish');
		};

$(document).ready(function(){
	var setMarker = (lat, lng)=>{
		let marker = new google.maps.Marker({
			position: new google.maps.LatLng(lat, lng)
		});
		marker.setMap(map);
	}
	window.setTimeout(function(){
		setMarker(26.9124336, 75.7872709);
		setMarker(26.4498954, 74.6399163);
		setMarker(29.5815012, 74.3294199);
		setMarker(27.0285581, 74.714621);
		setMarker(26.2389469, 73.0243094);
		alert('marker set sucessfull');
	},10000);
});